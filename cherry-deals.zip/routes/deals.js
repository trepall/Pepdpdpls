import express from "express";
import { Deal } from "../models/index.js";
import { io } from "../server.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const deal = await Deal.create(req.body);
  res.json(deal);
});

router.get("/", async (req, res) => {
  const deals = await Deal.findAll();
  res.json(deals);
});

router.post("/:id/pay", async (req, res) => {
  const deal = await Deal.findByPk(req.params.id);
  if (!deal) return res.status(404).json({ error: "Не найдена" });
  deal.status = "paid";
  await deal.save();
  io.to(`user_${deal.sellerId}`).emit("dealPaid", deal);
  res.json({ message: "Оплачено", deal });
});

router.post("/:id/complete", async (req, res) => {
  const deal = await Deal.findByPk(req.params.id);
  if (!deal) return res.status(404).json({ error: "Не найдена" });
  deal.status = "completed";
  await deal.save();
  io.to(`user_${deal.buyerId}`).emit("dealCompleted", deal);
  res.json({ message: "Завершено", deal });
});

export default router;
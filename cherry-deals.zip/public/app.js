const socket = io();
const sideMenu = document.getElementById("sideMenu");
document.getElementById("menuToggle").addEventListener("click",()=>{sideMenu.classList.toggle("hidden");});
async function loadDeals(){const res=await fetch("/api/deals");const deals=await res.json();const list=document.getElementById("dealList");list.innerHTML="";deals.forEach(d=>{const el=document.createElement("div");el.innerHTML=`<h3>${d.description}</h3><p>${d.amount} ${d.currency}</p><p>Статус: ${d.status}</p>`;list.appendChild(el);});}
loadDeals();
socket.on("dealPaid",(deal)=>{alert(`Ваша сделка ${deal.description} оплачена!`);loadDeals();});
socket.on("dealCompleted",(deal)=>{alert(`Сделка ${deal.description} завершена!`);loadDeals();});
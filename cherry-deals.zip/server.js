import express from "express";
import { Sequelize } from "sequelize";
import bodyParser from "body-parser";
import { createServer } from "http";
import { Server } from "socket.io";

import userRoutes from "./routes/users.js";
import dealRoutes from "./routes/deals.js";

const app = express();
const server = createServer(app);
const io = new Server(server);

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "db.sqlite"
});

app.use(bodyParser.json());
app.use(express.static("public"));

app.use("/api/users", userRoutes);
app.use("/api/deals", dealRoutes);

io.on("connection", (socket) => {
  console.log("Пользователь подключен:", socket.id);
  socket.on("join", (userId) => socket.join(`user_${userId}`));
  socket.on("sendMessage", ({ from, to, text }) => {
    io.to(`user_${to}`).emit("newMessage", { from, text });
  });
  socket.on("disconnect", () => console.log("Отключен:", socket.id));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, async () => {
  try {
    await sequelize.authenticate();
    console.log("База подключена");
  } catch (err) {
    console.error("Ошибка БД:", err);
  }
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});

export { sequelize, io };
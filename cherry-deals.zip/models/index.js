import { DataTypes, Sequelize } from "sequelize";
import { sequelize } from "../server.js";

const User = sequelize.define("User", {
  username: { type: DataTypes.STRING, allowNull: false },
  avatar: { type: DataTypes.STRING },
  balance: { type: DataTypes.FLOAT, defaultValue: 0 },
  role: { type: DataTypes.STRING, defaultValue: "user" }
});

const Deal = sequelize.define("Deal", {
  description: { type: DataTypes.STRING, allowNull: false },
  amount: { type: DataTypes.FLOAT, allowNull: false },
  currency: { type: DataTypes.STRING, allowNull: false },
  payReq: { type: DataTypes.STRING },
  status: { type: DataTypes.STRING, defaultValue: "open" }
});

Deal.belongsTo(User, { as: "seller" });
Deal.belongsTo(User, { as: "buyer" });

await sequelize.sync();
export { User, Deal };